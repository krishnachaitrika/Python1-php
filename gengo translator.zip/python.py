from flask import Flask, render_template, request
from translate import Translator

app = Flask(__name__)

# Language options for translation
language_options = {
    "es": "Spanish",
    "fr": "French",
    "de": "German",
    "it": "Italian",
    "ja": "Japanese"
}

@app.route("/", methods=["GET", "POST"])
def translate_text():
    translated_text = ""
    if request.method == "POST":
        text = request.form["text"]
        selected_lang = request.form["language"]

        # Perform translation
        translator = Translator(to_lang=selected_lang)
        translated_text = translator.translate(text)

    return render_template("index.html", languages=language_options, translated_text=translated_text)

if __name__ == "__main__":
    app.run(debug=True)
