from nltk.sentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
import nltk

# Download VADER if not already downloaded
nltk.download('vader_lexicon')

# Initialize Sentiment Analyzer
sia = SentimentIntensityAnalyzer()

def analyze_sentiment():
    comment = input("Enter a comment: ")
    
    # VADER Sentiment Score
    sentiment_score = sia.polarity_scores(comment)
    compound_score = sentiment_score['compound']
    
    # TextBlob Sentiment Score (for comparison)
    blob = TextBlob(comment)
    textblob_score = blob.sentiment.polarity
    
    # Determine sentiment category
    if compound_score >= 0.05:
        sentiment = "Positive"
    elif compound_score <= -0.05:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"
    
    result = {
        "Comment": comment,
        "VADER Score": compound_score,
        "TextBlob Score": textblob_score,
        "Sentiment": sentiment
    }
    
    print(result)

# Example usage
if __name__ == "__main__":
    analyze_sentiment()