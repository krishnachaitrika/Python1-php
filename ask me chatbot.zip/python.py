from flask import Flask, render_template, request, jsonify
from transformers import pipeline

app = Flask(__name__)

qa_pipeline = pipeline("question-answering")

context = """
The modern-day computer has become an important part of our daily life.
Also, their usage has increased significantly during the last decade.
Nowadays, computers are used in every office, whether private or government.
Mankind has been using computers for decades now.
They are used in many fields like agriculture, designing, machinery making, defense, and many more.
Above all, they have revolutionized the world.
It is very difficult to find the exact origin of computers.
However, some experts believe computers existed during World War II.
At that time, they were used for storing data, but only for government use.
In the beginning, computers were very large and heavy machines.
Computers are categorized into different types, including supercomputers, mainframes, personal computers (desktops),
PDAs, laptops, etc.
A computer is an electronic device that processes data and performs tasks according to programmed instructions. 
It consists of both hardware and software components. 
The hardware includes input devices like keyboards, mice, and scanners, which allow users to enter data. 
The Central Processing Unit (CPU), often called the brain of the computer, processes this data with the help of memory components 
like RAM (Random Access Memory) for temporary storage and hard drives or SSDs for long-term storage.
 The motherboard connects all components, allowing communication between the processor, memory, and other peripherals. 
 Output devices such as monitors, printers, and speakers display or present results. 
 The software, which includes the operating system (e.g., Windows, macOS, Linux) and applications like web browsers and word 
 processors, enables users to interact with the hardware and perform tasks. Computers come in 
 
 , including desktops, 
 laptops, tablets, and servers, each designed for specific uses.
 With advancements in technology, modern computers also integrate artificial intelligence, cloud computing, and high-speed 
 networking, making them essential in almost every field, from education and business to healthcare and entertainment.
 cpu full form is Central Processing Unit (CPU)"""

@app.route("/")
def index():
    return render_template("v.html")

@app.route("/ask", methods=["POST"])
def ask():
    data = request.json
    question = data.get("question")

    if not question:
        return jsonify({"error": "No question provided"}), 400

    result = qa_pipeline(question=question, context=context)
    answer = result["answer"]

    return jsonify({"question": question, "answer": answer})

if __name__ == "__main__":
    app.run(debug=True)
